<?php
// Front page template for Northstar Codeworks WordPress theme
get_header();
?>
<main class="site-main">
  <section class="hero">
    <div class="container">
      <h1>Welcome to Northstar Codeworks</h1>
      <p>We build reliable software solutions that help businesses grow and scale.</p>
      <a href="#contact" class="cta-button">Book a Consultation</a>
    </div>
  </section>

  <section class="trust-bar">
    <div class="container">
      <h2>Trusted by Leading Companies</h2>
      <div class="trust-metrics">
        <div class="metric-item"><strong>10+</strong> years in business</div>
        <div class="metric-item"><strong>500+</strong> projects completed</div>
        <div class="metric-item"><strong>95%</strong> client satisfaction</div>
      </div>
    </div>
  </section>

  <section class="services-preview">
    <div class="container">
      <h2>Our Services</h2>
      <div class="service-cards">
        <a href="/services/custom-web-applications/" class="service-card">
          <img src="/wp-content/themes/007_nolan_young_theme_testing/images/service-custom-web.png" alt="Custom Web Applications">
          <h3>Custom Web Applications</h3>
          <p>Create a web application tailored to your business needs.</p>
        </a>
        <a href="/services/internal-tools/" class="service-card">
          <img src="/wp-content/themes/007_nolan_young_theme_testing/images/service-internal-tools.png" alt="Internal Tools and Admin Portals">
          <h3>Internal Tools and Admin Portals</h3>
          <p>Streamline your internal operations with custom tools.</p>
        </a>
        <a href="/services/api-integrations/" class="service-card">
          <img src="/wp-content/themes/007_nolan_young_theme_testing/images/service-api-integrations.png" alt="API Integrations">
          <h3>API Integrations</h3>
          <p>Connect your tools and data seamlessly.</p>
        </a>
        <a href="/services/automation-systems/" class="service-card">
          <img src="/wp-content/themes/007_nolan_young_theme_testing/images/service-automation.png" alt="Workflow Automation Systems">
          <h3>Workflow Automation Systems</h3>
          <p>Automate repetitive tasks for efficiency.</p>
        </a>
      </div>
    </div>
  </section>

  <section class="problem-solution">
    <div class="container">
      <h2>Replace Manual Workflows and Disconnected Tools</h2>
      <p>Northstar Codeworks helps businesses replace fragile spreadsheets, disconnected SaaS tools, and manual processes with reliable software.</p>
    </div>
  </section>

  <section class="process">
    <div class="container">
      <h2>Our Process</h2>
      <ol class="process-steps">
        <li><strong>Discovery:</strong> Understand your business and goals.</li>
        <li><strong>Architecture:</strong> Design a scalable technical solution.</li>
        <li><strong>Build:</strong> Develop and test the application.</li>
        <li><strong>Launch:</strong> Deploy and go live.</li>
        <li><strong>Support:</strong> Maintain and optimize for performance.</li>
      </ol>
    </div>
  </section>

  <section class="featured-work">
    <div class="container">
      <h2>Featured Work</h2>
      <div class="case-studies">
        <a href="/work/operations-dashboard/" class="case-study-card">
          <img src="/wp-content/themes/007_nolan_young_theme_testing/images/case-study-ops-dashboard.png" alt="Operations Dashboard for a Multi-location Service Business">
          <h3>Operations Dashboard</h3>
          <p>Improved visibility and control across multiple locations.</p>
        </a>
        <a href="/work/client-portal/" class="case-study-card">
          <img src="/wp-content/themes/007_nolan_young_theme_testing/images/case-study-client-portal.png" alt="Client Portal for a Professional Services Firm">
          <h3>Client Portal</h3>
          <p>Secure access and management for clients.</p>
        </a>
      </div>
    </div>
  </section>

  <section class="testimonials">
    <div class="container">
      <h2>What Our Clients Say</h2>
      <div class="testimonial-cards">
        <blockquote>
          <p>Northstar Codeworks exceeded our expectations with their custom web application. It has significantly improved our operational efficiency.</p>
          <cite>- John Doe, CEO of Example Corp</cite>
        </blockquote>
        <blockquote>
          <p>Their API integrations have streamlined our workflow and reduced errors dramatically.</p>
          <cite>- Jane Smith, IT Manager at XYZ Inc</cite>
        </blockquote>
      </div>
    </div>
  </section>

  <section class="faq">
    <div class="container">
      <h2>Frequently Asked Questions</h2>
      <ul class="faq-list">
        <li><strong>How long does a project typically take?</strong> The duration varies based on the complexity, but we aim to deliver within 3-6 months.</li>
        <li><strong>Do you offer ongoing support?</strong> Yes, we provide maintenance and support for all our projects to ensure long-term success.</li>
        <li><strong>What industries do you serve?</strong> We specialize in serving software development companies, B2B teams, and growing service businesses.</li>
      </ul>
    </div>
  </section>

  <section class="final-cta">
    <div class="container">
      <h2>Ready to Grow Your Business?</h2>
      <a href="#contact" class="cta-button">Book a Consultation</a>
    </div>
  </section>
</main>
<?php get_footer(); ?>
