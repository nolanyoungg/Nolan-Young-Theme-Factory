<?php /* Template Name: Policy */ get_header(); ?><?php get_template_part( 'template-parts/content', 'policy' ); ?><?php get_footer(); ?>
