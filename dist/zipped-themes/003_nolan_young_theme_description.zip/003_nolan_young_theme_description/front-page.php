<?php get_header(); ?>
<?php
/* Template map: content-home-hero, content-home-services, content-home-proof, content-home-work, content-home-process, content-home-testimonials, content-blog-preview, content-home-cta. */
?>
<?php get_template_part( 'template-parts/content', 'home-hero' ); ?>
<?php get_template_part( 'template-parts/content', 'home-services' ); ?>
<?php get_template_part( 'template-parts/content', 'home-proof' ); ?>
<?php get_template_part( 'template-parts/content', 'home-work' ); ?>
<?php get_template_part( 'template-parts/content', 'home-process' ); ?>
<?php get_template_part( 'template-parts/content', 'home-testimonials' ); ?>
<?php get_template_part( 'template-parts/content', 'blog-preview' ); ?>
<?php get_template_part( 'template-parts/content', 'home-cta' ); ?>
<?php get_footer(); ?>