<?php
/**
 * Template part: content-single.php
 *
 * @package 008_nolan_young_theme_testing
 */
?>
<article class="content-card"><h2><?php the_title(); ?></h2><div><?php the_content(); ?></div></article>
