export function ready( callback ) {
	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', callback, {
			once: true,
		} );
		return;
	}
	callback();
}
