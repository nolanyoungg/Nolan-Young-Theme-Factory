<?php return array('dependencies' => array(), 'version' => 'f94b2290802eed568fd1');
