# Customization

Customize global colors, spacing, typography, and component styling in `src/scss/`. The compiled files in `assets/css/bundle.css` and `assets/js/bundle.js` are generated outputs and should keep their required names.

Business copy lives in templates and helper data arrays. Replace neutral Circuit Commerce Studio content with verified business details only when those details are supplied.

