<?php get_header(); ?><main id="primary" class="site-main"><header class="page-header"><?php the_archive_title( '<h1>', '</h1>' ); ?></header><?php if ( have_posts() ) : while ( have_posts() ) : the_post(); get_template_part( 'template-parts/content', 'search' ); endwhile; else : get_template_part( 'template-parts/content', 'none' ); endif; ?></main><?php get_footer(); ?>

